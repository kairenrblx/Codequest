import os
import noise
import json

def generate_world(size=50, height=10, seed=42, filename="world_data/world.json"):
    os.makedirs("world_data", exist_ok=True)
    world = {}
    for x in range(size):
        for z in range(size):
            h = int(noise.pnoise2(x * 0.1, z * 0.1, octaves=3, base=seed) * height) + 5
            for y in range(h):
                world[f"{x},{y},{z}"] = "stone" if y < h - 1 else "grass"
    
    with open(filename, "w") as f:
        json.dump(world, f, indent=4)
    
    print(f"World generated and saved to {filename}")
    return world
